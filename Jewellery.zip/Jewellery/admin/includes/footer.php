<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>All rights reserved</b>
    </div>
       <div class="phone">
              Telephone:
              <a class="phone__number" href="tel:2345678"2345678</a>
            </div>
            <div class="email">
              Email:
              <a href="mailto:suppor@gemsgalore.com" class="email__addr">gemsgalore.com</a>
</footer>
